import "./App.css";
import Banner1 from "./component/banner/Banner1";
import SlideRightToLeft from "./component/startups500/SlideRightToLeft";
import TestimonialSection from "./component/testimonialSection/testimonialSection";
import CoreTeam from "./component/coreTeam/CoreTeam";
import Input from "./component/inputs/input";
import Button from "./component/button/Button";
import AffordablePricing from "./component/affordablePricing/AffordablePricing";
import SimpleSteps from "./component/SimpleSteps/SimpleSteps";
import FinoTeamCard from "./component/finoTeamCard/FinoTeamCard";
import SlideSection from "./component/reviewSlider/SlideSection";
import { useState } from "react";
import Dialog from "./component/modal/Dialog";
import GoogleSlider from "./component/googleReview/GoogleSlider";
import PeopleTrustslider from "./component/PeopleTrustReviewer/PeopleTrustslider";
import Footer from "./component/footer/Footer";
import GetCallBack from "./component/getCallback/GetCallBack";
import { Routes, Route } from "react-router-dom";
import Fb from "./pages/fb";

function App() {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  return (
    <>
      <Routes>
        <Route path="/fb" element={<Fb />} />
      </Routes>
      <Dialog isOpen={isDialogOpen} onClose={() => setIsDialogOpen(false)}>
        <div className="text-center">
          <h2 className="text-2xl font-semibold">Consultation by Expert</h2>
        </div>
        <form className="" onSubmit="">
          <div>
            <div className="mb-5">
              <Input type="text" name="name" placeHolder="Enter Name" />
            </div>
            <div className="mb-5">
              <Input type="email" name="email" placeHolder="Enter Email ID" />
            </div>
            <div className="mb-5">
              <Input type="tel" name="mobile" placeHolder="Enter Mobile No." />
            </div>
            <div className="text-center">
              <Button
                Type="submit"
                className={`bg-blue-950 text-2xl text-white px-8 py-3 rounded-full cursor-pointer w-full hover:bg-blue-700`}
              >
                Submit
              </Button>
            </div>
          </div>
        </form>
      </Dialog>
      <Banner1 />
      <SlideRightToLeft />
      <section className="card-section mt-15 bg-[#ECF4FF] py-10">
        <div className="text-center w-1/2 m-auto x">
          <h2 className="text-2xl md:text-5xl font-semibold leading-[60px]">
            Complete Accounting Services for Every Business Need
          </h2>
          <p className="">
            If you're a small business or a CPA/accounting firm in the USA, our
            customized services can help you manage your accounting efficiently,
            with accuracy and compliance at every step.
          </p>
        </div>
        <div className="grid grid-cols-2 gap-8 w-2/3 m-auto mt-10">
          <div
            className="h-[222px] w-[100%]"
            style={{
              backgroundImage:
                "url('https://thefinopartners.com/public/assets/reactimg/Accounting-Services-box.png')",
              backgroundRepeat: "no-repeat",
              backgroundSize: "contain",
            }}
          >
            <p className="font-medium flex text-center text-white items-center h-[100%] m-auto justify-center text-3xl leading-[40px]">
              Accounting Services for Businesses
            </p>
          </div>
          <div
            className="h-[222px] w-[100%]"
            style={{
              backgroundImage:
                "url('https://thefinopartners.com/public/assets/reactimg/CPA-Accounting-Box.png')",
              backgroundRepeat: "no-repeat",
              backgroundSize: "contain",
            }}
          >
            <p className="font-medium flex text-center text-white items-center h-[100%] m-auto justify-center text-3xl leading-[40px]">
              Accounting Services for Businesses
            </p>
          </div>
        </div>
      </section>
      <GetCallBack />
      <section className="companytrust500-secion mt-15 ">
        <div className="text-center">
          <h2 className="text-2xl md:text-4xl font-semibold">
            350+ Company Trust us!
          </h2>
          <div className="text-center">
            <img
              className="mb-5 m-auto"
              src="https://thefinopartners.com/public/assets/reactimg/Company-Trust-us-logo-1.png"
              alt="Company-Trust-us-logo"
            />
            <img
              className="m-auto"
              src="https://thefinopartners.com/public/assets/reactimg/Company-Trust-us-logo-2.png"
              alt="Company-Trust-us-logo"
            />
          </div>
        </div>
      </section>
      <section className="md:p-10 p-5 mt-5 bg-[#041234] text-white">
        <div className="grid grid-cols-1 md:grid-cols-[1.3fr_1fr]">
          <div className="pr-4 md:w-5/6 w-full">
            <h2 className="text-2xl md:text-5xl leading-15">
              <span className="font-semibold">IOP Business Leader </span>
              <span className="font-semibold"> Says About Us!</span>
            </h2>
            <p className="text-lg">
              The Fino Partners have completely changed how we handle our
              accounting. Before working with them, we were always behind on our
              books. Now everything is on time, clean, and accurate. Their team
              is professional, responsive, and easy to talk to. We love that
              they explain everything in simple terms and actually care about
              our business.
            </p>
          </div>
          <div className="p-4 m-auto">
            <div>
              <img
                src="https://thefinopartners.com/public/assets/reactimg/John-Hansen-Carter-img.png"
                alt=""
                style={{ width: "100%," }}
              />
            </div>
          </div>
        </div>
      </section>
      <AffordablePricing setIsDialogOpen={setIsDialogOpen} />
      <SimpleSteps />
      <PeopleTrustslider />
      <section className="md:p-10 p-5 mt-5 bg-[#041234] text-white ">
        <div className="grid grid-cols-1 md:grid-cols-[1fr_1.3fr] place-items-center">
          <div className="p-4 m-auto mr-5">
            <div>
              <img
                src="https://www.thefinopartners.com/public/assets/reactimg/our-Strength-img-Mask group.png"
                alt=""
                style={{ width: "100%," }}
              />
            </div>
          </div>
          <div className="pr-4">
            <h2 className="text-2xl md:text-5xl">
              <span className="font-extralight">Our Strength & Heading</span>
            </h2>
            <p className="">
              Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut at
              ligula eu orci finibus blandit sit amet vel dolor. Nulla volutpat
              leo ipsum, ac ullamcorper velit venenatis eget.
            </p>
            <p className="">
              At sagittis augue malesuada ut. Vivamus ut tristique est. Etiam
              sit amet purus pulvinar mi varius pharetra vehicula eget nisl.
              Nunc ultricies dictum metus, eget interdum nibh maximus ut
            </p>
          </div>
        </div>
      </section>
      <FinoTeamCard setIsDialogOpen={setIsDialogOpen} />
      <section
        className="mt-15 get-a-call-back-section m-auto px-10 py-5  text-white"
        style={{
          backgroundImage:
            "url('https://thefinopartners.com/public/assets/reactimg/Get-a-Call-Back-bg.webp')",
          backgroundRepeat: "no-repeat",
          backgroundSize: "cover",
        }}
      >
        <div className="grid grid-cols-1 md:grid-cols-12 gap-5">
          <div className="md:col-span-4 ">
            <h2 className="text-2xl md:text-4xl">Get a Call Back</h2>
            <p>
              Request a callback from us for more inquiry, by filling out the
              details asked ahead
            </p>
          </div>
          <div className=" md:flex items-center gap-4 md:col-span-8 ">
            <Input
              className="w-full h-12 border border-[#8b929d] rounded-sm mb-4"
              inputClassName={`outline-0  border-0`}
              placeholder="Email Id"
            />
            <Input
              className="w-full h-12 border border-[#8b929d] rounded-sm mb-4"
              inputClassName={`outline-0  border-0`}
              placeholder="Mobile No."
            />
            <Button
              className={`w-full h-12 bg-[#0A6CFF] hover:bg-blue-400 cursor-pointer mb-4`}
            >
              Send
            </Button>
          </div>
        </div>
      </section>
      <section className=" mt-15 text-center md:px-20 px-5">
        <div>
          <h2 className="text-2xl md:text-4xl font-semibold">
            Softwares We Use for Providing Outsourced Accounting Services
          </h2>
          <p>
            We use the latest, and most trusted accounting software to guarantee
            efficient, accurate, and secure service for each and every one of
            our clients. We use technology to make your financial processes more
            efficient and error-free.
          </p>
        </div>
        <div className="text-center">
          <img
            className="mb-5 m-auto"
            src="https://thefinopartners.com/public/assets/reactimg/Software-logo-1.png"
            alt="Company-Trust-us-logo"
          />
          <img
            className="m-auto"
            src="https://thefinopartners.com/public/assets/reactimg/Software-logo-2.png"
            alt="Company-Trust-us-logo"
          />
        </div>
      </section>
      <GoogleSlider />
      <section className=" text-white mt-15">
        <div className="text-center md:w-1/2 m-auto text-black">
          <h2 className="text-2xl md:text-4xl font-semibold">Heading Text</h2>
          <p>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut at
            ligula eu orci finibus blandit sit amet vel dolor. Nulla volutpat
            leo ipsum, ac ullamcorper velit venenatis eget.
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 w-2/3 gap-5 m-auto">
          <div
            className=" text-center p-5 rounded-2xl"
            style={{
              backgroundImage:
                "url('https://thefinopartners.com/public/assets/reactimg/Ben-White-blu-bg.png')",
              backgroundRepeat: "no-repeat",
              backgroundSize: "cover",
            }}
          >
            <img
              className="w-[85px] h-[85px] rounded-full m-auto"
              src="https://www.startupfino.com/frontend/assets/usimage/ben-white-ai.png"
              alt="ben white"
            />
            <p className="text-2xl font-medium mt-4">Ben White</p>
            <p className="mt-[-10px]">Director of Growth</p>
            <div className="mt-5">
              <a
                className=" px-5 py-2 rounded-full bg-blue-900 text-white"
                href="https://calendly.com/ben-thefinopartners/30min"
                target="_blank"
              >
                Book a Call
              </a>
            </div>
          </div>
          <div
            className=" text-center p-5 rounded-2xl"
            style={{
              backgroundImage:
                "url('https://thefinopartners.com/public/assets/reactimg/Ben-White-orng-bg.png')",
              backgroundRepeat: "no-repeat",
              backgroundSize: "cover",
            }}
          >
            <img
              className="w-[85px] h-[85px] rounded-full m-auto"
              src="https://www.startupfino.com/frontend/assets/usimage/ben-white-ai.png"
              alt="ben white"
            />
            <p className="text-2xl font-medium mt-4">Ben White</p>
            <p className="mt-[-10px]">Director of Growth</p>
            <div className="mt-5">
              <a
                className=" px-5 py-2 rounded-full bg-blue-900 text-white"
                href="https://calendly.com/ben-thefinopartners/30min"
                target="_blank"
              >
                Book a Call
              </a>
            </div>
          </div>
        </div>
      </section>
      <section className="md:px-20 px-5 mt-15">
        <div className="text-center md:w-2/3 m-auto mb-10">
          <h2 className="md:text-4xl text-2xl font-semibold">
            10+ Industries We Serve
          </h2>
          <p>
            We provide specialized accounting services for businesses as well as
            CPA firms across more than 10+ industries, bringing customized
            solutions that meet all the different financial needs of each
            sector.
          </p>
        </div>
        <div className="flex flex-wrap gap-5 justify-center">
          <a className="bg-[#D3D3D3] rounded-full px-10 py-2 text-[#4D4E50]">
            CPA & Accounting Firms
          </a>
          <a className="bg-[#D3D3D3] rounded-full px-10 py-2 text-[#4D4E50]">
            Real Estate
          </a>
          <a className="bg-[#D3D3D3] rounded-full px-10 py-2 text-[#4D4E50]">
            Healthcare
          </a>
          <a className="bg-[#D3D3D3] rounded-full px-10 py-2 text-[#4D4E50]">
            Hospitality
          </a>
          <a className="bg-[#D3D3D3] rounded-full px-10 py-2 text-[#4D4E50]">
            Retail
          </a>
          <a className="bg-[#D3D3D3] rounded-full px-10 py-2 text-[#4D4E50]">
            Legal & Professional Services
          </a>
          <a className="bg-[#D3D3D3] rounded-full px-10 py-2 text-[#4D4E50]">
            Construction
          </a>
          <a className="bg-[#D3D3D3] rounded-full px-10 py-2 text-[#4D4E50]">
            Technology & Startups
          </a>
          <a className="bg-[#D3D3D3] rounded-full px-10 py-2 text-[#4D4E50]">
            Logistics & Transportation
          </a>
          <a className="bg-[#D3D3D3] rounded-full px-10 py-2 text-[#4D4E50]">
            Saas Startups
          </a>
          <a className="bg-[#D3D3D3] rounded-full px-10 py-2 text-[#4D4E50]">
            FinTech Startups
          </a>
          <a className="bg-[#D3D3D3] rounded-full px-10 py-2 text-[#4D4E50]">
            AI & Machine Learning
          </a>
        </div>
      </section>
      {/* <TestimonialSection />

      <CoreTeam />

      <SlideSection /> */}
      <Footer />
    </>
  );
}

export default App;
