import React from "react";

function Fb() {
  return <div>Fb</div>;
}

export default Fb;
