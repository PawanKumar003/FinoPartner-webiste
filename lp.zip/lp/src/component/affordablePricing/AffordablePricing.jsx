import React from "react";
import { IoIosCheckboxOutline } from "react-icons/io";
import Button from "../button/Button";

const pricing = [
  "Accounting And Bookkeeping ",
  "Backlog Clearance",
  "Payroll Processing",
  "Cash Flow Management",
  "Budget Management ",
  "Year-End Billing",
  "Sales Tax Filing",
];
const pricing1 = [
  "Hire An Accountant/CPA Part Time Or Full Time",
  "Minimum 5+ Years Of US Accounting Experience",
  "Quickbooks Excellence",
  "Payroll Expert",
  "MIS Reporting",
  "Fluent And Clear Communication",
  "Availability At Your Time Zone",
];
function AffordablePricing({ setIsDialogOpen }) {
  return (
    <section className="price-section">
      <div className="text-2xl md:text-4xl font-bold text-center mt-15 mb-10">
        <h2>Services with Affordable Pricing</h2>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 w-2/3 gap-5 m-auto">
        <div className="text-center">
          <div className="bg-[#0A6CFF] text-white p-5 rounded-t-2xl">
            <h3 className="text-2xl font-medium">Offer for Business Owners</h3>
          </div>
          <div className="bg-[#F2F5FD] pb-4 rounded-b-2xl">
            <ul className="p-4">
              {pricing.map((item) => (
                <li className="flex items-center text-xl mb-4">
                  <IoIosCheckboxOutline className="mr-2 text-2xl text-[#0A6CFF]" />
                  {item}
                </li>
              ))}
            </ul>
            <div className="border border-[#0A6CFF] w-2/3 m-auto rounded-full p-3 text-4xl font-medium hover:bg-[#0A6CFF] hover:text-white">
              <Button onClick={setIsDialogOpen} className="cursor-pointer">
                Get Quote
              </Button>
            </div>
          </div>
        </div>
        <div className="text-center">
          <div className="bg-[#0F3BA2] text-white p-5 rounded-t-2xl">
            <h3 className="text-2xl font-medium">
              Offer for Accounting Firm Owner
            </h3>
          </div>
          <div className="bg-[#F2F5FD] pb-4 rounded-b-2xl">
            <ul className="p-4">
              {pricing1.map((item) => (
                <li className="flex items-center text-xl mb-4">
                  <IoIosCheckboxOutline className="mr-2 text-2xl text-[#0A6CFF]" />
                  {item}
                </li>
              ))}
            </ul>
            <div className="border border-[#0A6CFF] w-2/3 m-auto rounded-full p-3 text-4xl font-medium hover:bg-[#0F3BA2] hover:text-white">
              <Button onClick={setIsDialogOpen} className="cursor-pointer">
                Get Quote
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

export default AffordablePricing;
