import React from "react";
import { FaStar } from "react-icons/fa";
import PeopleTrustReview from "./PeopleTrustReview";

function PeopleTrustslider() {
  return (
    <section className=" pt-5 w-full ">
      <div className="grid grid-cols-2">
        <div className="bg-[#ECF4FF] py-10 px-10">
          <div className="text-black ">
            <h2 className="text-2xl md:text-5xl font-semibold leading-[60px]">
              Thousands of People Trust on our Services
            </h2>
            <p>
              More than thousands of business owners and CPA firms trust our
              services to deliver accurate, timely, and cost-effective
              accounting solutions. Join them and experience unparalleled
              financial management.
            </p>
            {/* <div className="mt-15">
              <a className="cursor-pointer bg-[#0A6CFF] text-white px-20 py-2 rounded-full">
                Book A Call
              </a>
            </div> */}
            <div className="flex items-center justify-center mt-10">
              <p className="text-[#FFBF0B] text-3xl font-medium border-r border-gray-500 pr-3 mr-3">
                4.98
              </p>
              <div className="">
                <p className="flex text-2xl mb-0">
                  <FaStar className="text-yellow-400" />
                  <FaStar className="text-yellow-400" />
                  <FaStar className="text-yellow-400" />
                  <FaStar className="text-yellow-400" />
                  <FaStar className="text-yellow-400" />
                </p>
                <p className="text-[#FFBF0B]">Avg. Clients Ratings</p>
              </div>
            </div>
          </div>
        </div>
        <div className="p-10">
          <PeopleTrustReview />
        </div>
      </div>
    </section>
  );
}

export default PeopleTrustslider;
