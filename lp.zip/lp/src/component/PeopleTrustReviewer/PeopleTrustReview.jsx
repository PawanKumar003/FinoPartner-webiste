import React from "react";
import { useKeenSlider } from "keen-slider/react";
import "keen-slider/keen-slider.min.css";

const PeopleTrustReview = () => {
  const [sliderRef] = useKeenSlider({
    loop: true,
    slides: {
      perView: 1,
      //   pauseOnMouseEnter: true,
    },
    created: (slider) => {
      setInterval(() => {
        slider.next();
      }, 3000); // 3 second delay
    },
  });

  return (
    <div
      ref={sliderRef}
      className="keen-slider overflow-hidden rounded-xl shadow-lg bg-white"
    >
      <div className="keen-slider__slide">
        <div className="">
          <img
            className="w-full md:h-[350px]"
            src="https://thefinopartners.com/public/assets/reactimg/google-reviews-box-1.png"
            alt="Keerti"
          />
        </div>
      </div>
      <div className="keen-slider__slide">
        <div className="">
          <img
            className="w-full md:h-[350px]"
            src="https://thefinopartners.com/public/assets/reactimg/google-reviews-box-2.png"
            alt="Keerti"
          />
        </div>
      </div>
      <div className="keen-slider__slide">
        <div className="">
          <img
            className="w-full md:h-[350px]"
            src="https://thefinopartners.com/public/assets/reactimg/google-reviews-box-3.png"
            alt="Keerti"
          />
        </div>
      </div>
      <div className="keen-slider__slide">
        <div className="">
          <img
            className="w-full md:h-[350px]"
            src="https://thefinopartners.com/public/assets/reactimg/google-reviews-box-4.png"
            alt="Keerti"
          />
        </div>
      </div>
    </div>
  );
};

export default PeopleTrustReview;
