import React from "react";
import { MdOutlineMailOutline } from "react-icons/md";
import { IoIosCall } from "react-icons/io";

function Footer() {
  return (
    <section className="footer md:px-10 px-4 py-5 bg-[#0f3ba2] text-white mt-15">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
        <div>
          <h2 className="text-3xl font-semibold">About us</h2>
          <p>
            At The Fino Partners, we offer a full-range of services for digital
            marketing and business solutions. From SEO and ads to accounting and
            fundraising, we help businesses grow smarter. With over 750+
            projects delivered, we’re known for results, reliability, and real
            support. In the challenging U.S. market, we're here to bring our
            expertise to your brand. Let’s work together to take your business
            to the next level.
          </p>
          <div className="flex items-center gap-5">
            <div className="flex items-center border border-gray-50 px-2">
              <div className="mr-5 ">
                <img
                  className="rounded-full h-[60px] w-[60px]"
                  src="https://thefinopartners.com/public/assets/images/USA.webp"
                  alt="usa"
                />
              </div>
              <div>
                <p className="text-xl font-semibold">Head Office:</p>
                <p>
                  16192, Coastal Highway <br />
                  Lewes Sussex Delaware 19958
                </p>
              </div>
            </div>
            <div className="flex items-center border border-gray-50 px-2">
              <div className="mr-5 ">
                <img
                  className="rounded-full h-[60px] w-[60px]"
                  src="https://thefinopartners.com/public/assets/images/USA.webp"
                  alt="usa"
                />
              </div>
              <div>
                <p className="text-xl font-semibold">Head Office:</p>
                <p>
                  16192, Coastal Highway <br />
                  Lewes Sussex Delaware 19958
                </p>
              </div>
            </div>
          </div>
        </div>
        <div>
          <h2 className="text-3xl font-semibold">Contact Us</h2>
          <p className="flex items-center tex-xl">
            <MdOutlineMailOutline className="text-3xl mr-3" />{" "}
            hello@thefinopartners.com
          </p>
          <p>
            <a href="tel:+16465513218" className="flex items-center text-xl">
              <IoIosCall className="text-3xl mr-3" /> +1-646-551-3218
            </a>
          </p>
          <h2 className="text-2xl font-medium mt-5">USA Office:</h2>
          <p>
            Fino Partners Group INC 16192, <br />
            Coastal Highway Lewes Sussex Delaware 19958
          </p>
          <div>
            <img
              src="https://thefinopartners.com/public/assets/images/payment gateway-img.png"
              alt="gateway"
            />
          </div>
        </div>
      </div>
    </section>
  );
}

export default Footer;
