import React from "react";

function Header() {
  return (
    <div className="flex ">
      <div>
        <img src="" alt="" />
      </div>
      <div>
        <ul>
          <li>Home</li>
          <li>Home</li>
          <li>Home</li>
          <li>Home</li>
          <li>Home</li>
        </ul>
      </div>
    </div>
  );
}

export default Header;
