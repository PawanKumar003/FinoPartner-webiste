import React from "react";
import Input from "../inputs/input";
import Button from "../button/Button";

function GetCallBack() {
  return (
    <section
      className="mt-15 get-a-call-back-section m-auto px-10 py-5  text-white"
      style={{
        backgroundImage:
          "url('https://thefinopartners.com/public/assets/reactimg/Get-a-Call-Back-bg.webp')",
        backgroundRepeat: "no-repeat",
        backgroundSize: "cover",
      }}
    >
      <div className="grid grid-cols-1 md:grid-cols-12 gap-5">
        <div className="md:col-span-4 ">
          <h2 className="text-2xl md:text-4xl">Get a Call Back</h2>
          <p>
            Request a callback from us for more inquiry, by filling out the
            details asked ahead
          </p>
        </div>
        <div className=" md:flex items-center gap-4 md:col-span-8 ">
          <Input
            className="w-full h-12 border border-[#8b929d] rounded-sm mb-4"
            inputClassName={`outline-0  border-0`}
            placeholder="Email Id"
          />
          <Input
            className="w-full h-12 border border-[#8b929d] rounded-sm mb-4"
            inputClassName={`outline-0  border-0`}
            placeholder="Mobile No."
          />
          <Button
            className={`w-full h-12 bg-[#0A6CFF] hover:bg-blue-400 cursor-pointer mb-4`}
          >
            Send
          </Button>
        </div>
      </div>
    </section>
  );
}

export default GetCallBack;
