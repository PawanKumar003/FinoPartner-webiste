import React from "react";
function SlideRightToLeft() {
  return (
    <section className="mt-15">
      <div className="md:flex sm:block md:items-center">
        <div className="text-2xl md:text-5xl font-normal md:w-1/2 text-center">
          Certified <span className="font-semibold">ISO</span>
        </div>
        <div className=" p-4 flex md:w-full overflow-hidden animate-slide-left">
          <img
            className="mr-4 h-[80px]"
            src="https://thefinopartners.com/public/assets/images/Security-logo.png"
            alt=""
          />
          <img
            className="h-[80px]"
            src="https://thefinopartners.com/public/assets/images/Security-logo.png"
            alt=""
          />
        </div>
      </div>
    </section>
  );
}

export default SlideRightToLeft;
