import React from "react";
import { FaStar } from "react-icons/fa";
import GoogleReview from "./GoogleReview";

function GoogleSlider() {
  return (
    <section className="md:px-10 pt-5 w-full px-5 bg-[#041234] mt-15">
      <div className="grid grid-cols-2">
        <div>
          <div className="text-white">
            <h2 className="text-5xl leading-[60px]">
              Pool of Expert People Available for You
            </h2>
            <p>
              Access our pool of over 250+ expert accountants dedicated to
              handling your financial needs with expertise and care. Expert
              help, now at your fingertips.
            </p>
            <div className="mt-15">
              <a
                href="https://calendly.com/ben-thefinopartners/30min"
                target="_blank"
                className="cursor-pointer bg-[#0A6CFF] text-white px-20 py-2 rounded-full"
              >
                Book A Call
              </a>
            </div>
          </div>
        </div>
        <div className="p-10">
          <GoogleReview />
        </div>
      </div>
    </section>
  );
}

export default GoogleSlider;
